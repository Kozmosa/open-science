# Test Cases for 12-14 Polymorphic Banking Program

**Input sequence:** `100 50 200 100 300 150`

| Account | Type | Initial | Deposit | Withdraw | Interest | Final |
|---------|------|---------|---------|----------|----------|-------|
| 1 | SavingsAccount (5%) | $1000.00 | $100.00 | $50.00 | $52.50 | $1102.50 |
| 2 | CheckingAccount ($2.50 fee) | $500.00 | $200.00 | $100.00 | N/A | $595.00 |
| 3 | SavingsAccount (3%) | $2000.00 | $300.00 | $150.00 | $64.50 | $2214.50 |

**Verification:**
- Account 1: (1000 + 100 - 50) * 1.05 = $1102.50
- Account 2: 500 + 200 - 2.50 - 100 - 2.50 = $595.00
- Account 3: (2000 + 300 - 150) * 1.03 = $2214.50
