#include <iostream>
#include <iomanip>
#include <vector>

class Account {
public:
    Account(double initialBalance = 0.0) {
        if (initialBalance >= 0.0)
            balance = initialBalance;
        else {
            balance = 0.0;
            std::cout << "Error: Invalid initial balance." << std::endl;
        }
    }

    virtual ~Account() {}

    virtual void credit(double amount) {
        balance += amount;
    }

    virtual bool debit(double amount) {
        if (amount > balance) {
            std::cout << "Debit amount exceeded account balance." << std::endl;
            return false;
        }
        balance -= amount;
        return true;
    }

    double getBalance() const { return balance; }

private:
    double balance;
};

class SavingsAccount : public Account {
public:
    SavingsAccount(double initialBalance, double rate)
        : Account(initialBalance), interestRate(rate) {}

    double calculateInterest() const {
        return getBalance() * interestRate;
    }

private:
    double interestRate;
};

class CheckingAccount : public Account {
public:
    CheckingAccount(double initialBalance, double fee)
        : Account(initialBalance), feePerTransaction(fee) {}

    virtual void credit(double amount) {
        Account::credit(amount);
        Account::debit(feePerTransaction);
    }

    virtual bool debit(double amount) {
        bool success = Account::debit(amount);
        if (success)
            Account::debit(feePerTransaction);
        return success;
    }

private:
    double feePerTransaction;
};

int main() {
    std::cout << std::fixed << std::setprecision(2);

    std::vector<Account*> accounts;
    accounts.push_back(new SavingsAccount(1000.0, 0.05));
    accounts.push_back(new CheckingAccount(500.0, 2.50));
    accounts.push_back(new SavingsAccount(2000.0, 0.03));

    for (std::size_t i = 0; i < accounts.size(); ++i) {
        std::cout << "\n=== Processing Account " << (i + 1) << " ===" << std::endl;
        std::cout << "Initial balance: $" << accounts[i]->getBalance() << std::endl;

        double deposit, withdraw;
        std::cout << "Enter deposit amount: ";
        std::cin >> deposit;
        accounts[i]->credit(deposit);

        std::cout << "Enter withdrawal amount: ";
        std::cin >> withdraw;
        accounts[i]->debit(withdraw);

        // Determine if SavingsAccount and calculate interest
        SavingsAccount* sa = dynamic_cast<SavingsAccount*>(accounts[i]);
        if (sa != 0) {
            double interest = sa->calculateInterest();
            std::cout << "Interest earned: $" << interest << std::endl;
            sa->credit(interest);
        }

        std::cout << "Updated balance: $" << accounts[i]->getBalance() << std::endl;
    }

    for (std::size_t i = 0; i < accounts.size(); ++i)
        delete accounts[i];

    return 0;
}
