#include <iostream>

class Complex {
public:
    Complex(double real = 0.0, double imag = 0.0)
        : realPart(real), imaginaryPart(imag) {}

    Complex add(const Complex& other) const {
        return Complex(realPart + other.realPart,
                       imaginaryPart + other.imaginaryPart);
    }

    Complex subtract(const Complex& other) const {
        return Complex(realPart - other.realPart,
                       imaginaryPart - other.imaginaryPart);
    }

    void print() const {
        std::cout << "(" << realPart << ", " << imaginaryPart << ")";
    }

private:
    double realPart;
    double imaginaryPart;
};

int main() {
    Complex a(3.0, 4.0);
    Complex b(1.0, 2.0);
    Complex c; // default 0+0i

    std::cout << "a = "; a.print(); std::cout << std::endl;
    std::cout << "b = "; b.print(); std::cout << std::endl;
    std::cout << "c = "; c.print(); std::cout << std::endl;

    Complex sum = a.add(b);
    std::cout << "a + b = "; sum.print(); std::cout << std::endl;

    Complex diff = a.subtract(b);
    std::cout << "a - b = "; diff.print(); std::cout << std::endl;

    Complex sum2 = a.add(c);
    std::cout << "a + c = "; sum2.print(); std::cout << std::endl;

    return 0;
}
