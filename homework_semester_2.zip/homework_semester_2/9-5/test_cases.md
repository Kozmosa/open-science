# Test Cases for 9-5 Complex Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Default constructor | `Complex c;` | `(0, 0)` |
| Parameterized constructor | `Complex a(3.0, 4.0)` | `(3, 4)` |
| Addition | `a.add(b)` where a=(3,4), b=(1,2) | `(4, 6)` |
| Subtraction | `a.subtract(b)` where a=(3,4), b=(1,2) | `(2, 2)` |
| Add with zero | `a.add(c)` where a=(3,4), c=(0,0) | `(3, 4)` |
| Negative values | `Complex(-2.5, -1.5).add(Complex(1.0, 0.5))` | `(-1.5, -1)` |
