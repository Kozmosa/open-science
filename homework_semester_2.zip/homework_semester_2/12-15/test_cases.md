# Test Cases for 12-15 Payroll System Modification

| Employee Type | Name | Details | Expected Earnings |
|--------------|------|---------|-------------------|
| SalariedEmployee | John Smith | $800/week salary | $800.00 |
| PieceWorker | Mary Jones | $12.50/piece, 85 pieces | $1062.50 = 12.50 * 85 |
| HourlyWorker | Bob Brown | $25.00/hr, 40 hours | $1000.00 = 25.00 * 40 |
| HourlyWorker | Alice Green | $20.00/hr, 50 hours | $1100.00 = 40*20 + 10*20*1.5 |

**Overtime calculation for Alice Green:**
- Regular: 40 hours * $20.00 = $800.00
- Overtime: 10 hours * $20.00 * 1.5 = $300.00
- Total: $1100.00
