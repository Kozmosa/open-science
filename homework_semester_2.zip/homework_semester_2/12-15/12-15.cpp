#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>
#include <string>

std::string fmtDouble(double val) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(2) << val;
    return oss.str();
}

class Employee {
public:
    Employee(const std::string& first, const std::string& last,
             const std::string& ssn)
        : firstName(first), lastName(last), socialSecurityNumber(ssn) {}

    virtual ~Employee() {}

    virtual double earnings() const = 0;

    virtual std::string toString() const {
        return firstName + " " + lastName + "\nSSN: " + socialSecurityNumber;
    }

    std::string getFirstName() const { return firstName; }
    std::string getLastName() const { return lastName; }
    std::string getSSN() const { return socialSecurityNumber; }

private:
    std::string firstName;
    std::string lastName;
    std::string socialSecurityNumber;
};

class SalariedEmployee : public Employee {
public:
    SalariedEmployee(const std::string& first, const std::string& last,
                     const std::string& ssn, double salary)
        : Employee(first, last, ssn), weeklySalary(salary) {}

    virtual double earnings() const {
        return weeklySalary;
    }

    virtual std::string toString() const {
        return "Salaried Employee: " + Employee::toString()
               + "\nWeekly Salary: $" + fmtDouble(weeklySalary);
    }

private:
    double weeklySalary;
};

class PieceWorker : public Employee {
public:
    PieceWorker(const std::string& first, const std::string& last,
                const std::string& ssn, double w, int p)
        : Employee(first, last, ssn), wage(w), pieces(p) {}

    virtual double earnings() const {
        return wage * pieces;
    }

    virtual std::string toString() const {
        return "Piece Worker: " + Employee::toString()
               + "\nWage per piece: $" + fmtDouble(wage)
               + "\nPieces produced: " + std::to_string(pieces);
    }

private:
    double wage;
    int pieces;
};

class HourlyWorker : public Employee {
public:
    HourlyWorker(const std::string& first, const std::string& last,
                 const std::string& ssn, double w, double hrs)
        : Employee(first, last, ssn), wage(w), hours(hrs) {}

    virtual double earnings() const {
        if (hours <= 40.0)
            return wage * hours;
        else
            return 40.0 * wage + (hours - 40.0) * wage * 1.5;
    }

    virtual std::string toString() const {
        return "Hourly Worker: " + Employee::toString()
               + "\nHourly wage: $" + fmtDouble(wage)
               + "\nHours worked: " + fmtDouble(hours);
    }

private:
    double wage;
    double hours;
};

int main() {
    std::cout << std::fixed << std::setprecision(2);

    std::vector<Employee*> employees;
    employees.push_back(new SalariedEmployee("John", "Smith",
        "111-11-1111", 800.00));
    employees.push_back(new PieceWorker("Mary", "Jones",
        "222-22-2222", 12.50, 85));
    employees.push_back(new HourlyWorker("Bob", "Brown",
        "333-33-3333", 25.00, 40.0));
    employees.push_back(new HourlyWorker("Alice", "Green",
        "444-44-4444", 20.00, 50.0));

    for (std::size_t i = 0; i < employees.size(); ++i) {
        std::cout << employees[i]->toString() << std::endl;
        std::cout << "Earnings: $" << employees[i]->earnings() << std::endl;
        std::cout << std::endl;
    }

    for (std::size_t i = 0; i < employees.size(); ++i)
        delete employees[i];

    return 0;
}
