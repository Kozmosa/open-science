#include <iostream>
#include <string>
#include <algorithm>

class HugeInteger {
public:
    static const int SIZE = 40;

    HugeInteger() {
        for (int i = 0; i < SIZE; ++i)
            digits[i] = 0;
    }

    void input(const std::string& num) {
        for (int i = 0; i < SIZE; ++i)
            digits[i] = 0;
        int len = static_cast<int>(num.size());
        for (int i = 0; i < len && i < SIZE; ++i)
            digits[i] = num[len - 1 - i] - '0';
    }

    void output() const {
        int i = SIZE - 1;
        while (i > 0 && digits[i] == 0) --i;
        for (; i >= 0; --i)
            std::cout << digits[i];
    }

    HugeInteger add(const HugeInteger& other) const {
        HugeInteger result;
        int carry = 0;
        for (int i = 0; i < SIZE; ++i) {
            int sum = digits[i] + other.digits[i] + carry;
            result.digits[i] = sum % 10;
            carry = sum / 10;
        }
        return result;
    }

    HugeInteger subtract(const HugeInteger& other) const {
        HugeInteger result;
        int borrow = 0;
        for (int i = 0; i < SIZE; ++i) {
            int diff = digits[i] - other.digits[i] - borrow;
            if (diff < 0) {
                diff += 10;
                borrow = 1;
            } else {
                borrow = 0;
            }
            result.digits[i] = diff;
        }
        return result;
    }

    HugeInteger multiply(const HugeInteger& other) const {
        HugeInteger result;
        for (int i = 0; i < SIZE; ++i) {
            int carry = 0;
            for (int j = 0; j < SIZE - i; ++j) {
                int prod = result.digits[i + j] + digits[i] * other.digits[j] + carry;
                result.digits[i + j] = prod % 10;
                carry = prod / 10;
            }
        }
        return result;
    }

    bool isEqualTo(const HugeInteger& other) const {
        for (int i = 0; i < SIZE; ++i)
            if (digits[i] != other.digits[i]) return false;
        return true;
    }

    bool isNotEqualTo(const HugeInteger& other) const {
        return !isEqualTo(other);
    }

    bool isGreaterThan(const HugeInteger& other) const {
        for (int i = SIZE - 1; i >= 0; --i) {
            if (digits[i] > other.digits[i]) return true;
            if (digits[i] < other.digits[i]) return false;
        }
        return false;
    }

    bool isLessThan(const HugeInteger& other) const {
        for (int i = SIZE - 1; i >= 0; --i) {
            if (digits[i] < other.digits[i]) return true;
            if (digits[i] > other.digits[i]) return false;
        }
        return false;
    }

    bool isGreaterThanOrEqualTo(const HugeInteger& other) const {
        return !isLessThan(other);
    }

    bool isLessThanOrEqualTo(const HugeInteger& other) const {
        return !isGreaterThan(other);
    }

    bool isZero() const {
        for (int i = 0; i < SIZE; ++i)
            if (digits[i] != 0) return false;
        return true;
    }

private:
    int digits[SIZE];
};

int main() {
    HugeInteger a, b;

    a.input("12345678901234567890");
    b.input("98765432109876543210");

    std::cout << "a = "; a.output(); std::cout << std::endl;
    std::cout << "b = "; b.output(); std::cout << std::endl;

    HugeInteger sum = a.add(b);
    std::cout << "a + b = "; sum.output(); std::cout << std::endl;

    HugeInteger diff = b.subtract(a);
    std::cout << "b - a = "; diff.output(); std::cout << std::endl;

    HugeInteger prod = a.multiply(HugeInteger());
    HugeInteger two; two.input("2");
    prod = a.multiply(two);
    std::cout << "a * 2 = "; prod.output(); std::cout << std::endl;

    std::cout << std::boolalpha;
    std::cout << "a == b: " << a.isEqualTo(b) << std::endl;
    std::cout << "a != b: " << a.isNotEqualTo(b) << std::endl;
    std::cout << "a > b: " << a.isGreaterThan(b) << std::endl;
    std::cout << "a < b: " << a.isLessThan(b) << std::endl;
    std::cout << "a <= b: " << a.isLessThanOrEqualTo(b) << std::endl;
    std::cout << "b >= a: " << b.isGreaterThanOrEqualTo(a) << std::endl;

    HugeInteger z;
    std::cout << "z isZero: " << z.isZero() << std::endl;
    std::cout << "a isZero: " << a.isZero() << std::endl;

    // Test subtraction with same numbers
    HugeInteger same;
    same.input("555");
    HugeInteger sdiff = same.subtract(same);
    std::cout << "555 - 555 = "; sdiff.output(); std::cout << std::endl;

    return 0;
}
