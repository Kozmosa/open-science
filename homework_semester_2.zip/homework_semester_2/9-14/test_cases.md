# Test Cases for 9-14 HugeInteger Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Default is zero | `HugeInteger z; z.output()` | `0` |
| isZero on default | `z.isZero()` | `true` |
| Input and output | `a.input("12345678901234567890")` | `12345678901234567890` |
| Addition | `a.add(b)` with a=123..., b=987... | `111111111011111111100` |
| Subtraction | `b.subtract(a)` | `86419753208641975320` |
| Self-subtract | `same.subtract(same)` | `0` |
| Multiplication | `a.multiply(two)` with two=2 | `24691357802469135780` |
| Comparison: a < b | `a.isLessThan(b)` | `true` |
| Comparison: a > b | `a.isGreaterThan(b)` | `false` |
| a != b | `a.isNotEqualTo(b)` | `true` |
| b >= a | `b.isGreaterThanOrEqualTo(a)` | `true` |
