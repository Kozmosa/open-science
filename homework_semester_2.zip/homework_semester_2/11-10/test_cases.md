# Test Cases for 11-10 Account Inheritance Hierarchy

| Test | Input | Expected Output |
|------|-------|-----------------|
| Account init | `Account acc(500)` | balance = $500.00 |
| Account credit | `acc.credit(100)` | balance = $600.00 |
| Account debit | `acc.debit(200)` | balance = $400.00, returns true |
| Account debit exceed | `acc.debit(1000)` | balance = $400.00, error message, returns false |
| Invalid Account | `Account bad(-50)` | balance = $0.00, error message |
| SavingsAccount interest | `sav.calculateInterest()` with $1000 at 5% | $50.00 |
| SavingsAccount credit interest | `sav.credit(interest)` | balance = $1050.00 |
| CheckingAccount credit | `chk.credit(100)` with $500 + $2.50 fee | balance = $597.50 |
| CheckingAccount debit success | `chk.debit(50)` | balance = $545.00, returns true |
| CheckingAccount debit fail | `chk.debit(1000)` | balance unchanged at $545.00, returns false, no fee |
