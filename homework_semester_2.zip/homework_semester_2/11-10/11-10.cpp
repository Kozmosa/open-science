#include <iostream>
#include <iomanip>

class Account {
public:
    Account(double initialBalance = 0.0) {
        if (initialBalance >= 0.0)
            balance = initialBalance;
        else {
            balance = 0.0;
            std::cout << "Error: Invalid initial balance." << std::endl;
        }
    }

    void credit(double amount) {
        balance += amount;
    }

    bool debit(double amount) {
        if (amount > balance) {
            std::cout << "Debit amount exceeded account balance." << std::endl;
            return false;
        }
        balance -= amount;
        return true;
    }

    double getBalance() const { return balance; }

private:
    double balance;
};

class SavingsAccount : public Account {
public:
    SavingsAccount(double initialBalance, double rate)
        : Account(initialBalance), interestRate(rate) {}

    double calculateInterest() const {
        return getBalance() * interestRate;
    }

private:
    double interestRate;
};

class CheckingAccount : public Account {
public:
    CheckingAccount(double initialBalance, double fee)
        : Account(initialBalance), feePerTransaction(fee) {}

    void credit(double amount) {
        Account::credit(amount);
        Account::debit(feePerTransaction);
    }

    bool debit(double amount) {
        bool success = Account::debit(amount);
        if (success)
            Account::debit(feePerTransaction);
        return success;
    }

private:
    double feePerTransaction;
};

int main() {
    std::cout << std::fixed << std::setprecision(2);

    // Test Account base class
    std::cout << "=== Account ===" << std::endl;
    Account acc(500.0);
    std::cout << "Initial balance: $" << acc.getBalance() << std::endl;
    acc.credit(100.0);
    std::cout << "After crediting $100: $" << acc.getBalance() << std::endl;
    acc.debit(200.0);
    std::cout << "After debiting $200: $" << acc.getBalance() << std::endl;
    acc.debit(1000.0); // should fail
    std::cout << "After failed debit: $" << acc.getBalance() << std::endl;

    // Test invalid initial balance
    std::cout << "\n=== Invalid Account ===" << std::endl;
    Account bad(-50.0);
    std::cout << "Balance: $" << bad.getBalance() << std::endl;

    // Test SavingsAccount
    std::cout << "\n=== SavingsAccount ===" << std::endl;
    SavingsAccount sav(1000.0, 0.05);
    std::cout << "Initial balance: $" << sav.getBalance() << std::endl;
    double interest = sav.calculateInterest();
    std::cout << "Calculated interest (5%): $" << interest << std::endl;
    sav.credit(interest);
    std::cout << "After crediting interest: $" << sav.getBalance() << std::endl;

    // Test CheckingAccount
    std::cout << "\n=== CheckingAccount ===" << std::endl;
    CheckingAccount chk(500.0, 2.5);
    std::cout << "Initial balance: $" << chk.getBalance() << std::endl;
    std::cout << "(fee is $2.50 per transaction)" << std::endl;

    chk.credit(100.0);
    std::cout << "After crediting $100 (minus fee): $" << chk.getBalance() << std::endl;

    chk.debit(50.0);
    std::cout << "After debiting $50 (minus fee): $" << chk.getBalance() << std::endl;

    chk.debit(1000.0); // should fail, no fee charged
    std::cout << "After failed debit (no fee): $" << chk.getBalance() << std::endl;

    std::cout << "\n=== Polymorphism ===" << std::endl;
    Account* a1 = &sav;
    Account* a2 = &chk;
    std::cout << "SavingsAccount balance via Account*: $" << a1->getBalance() << std::endl;
    std::cout << "CheckingAccount balance via Account*: $" << a2->getBalance() << std::endl;

    return 0;
}
