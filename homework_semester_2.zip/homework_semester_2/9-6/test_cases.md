# Test Cases for 9-6 Rational Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Default constructor | `Rational d;` | `0/1` |
| Reduction | `Rational(2, 4)` | `1/2` |
| Reduction | `Rational(50, 100)` | `1/2` |
| Addition | `Rational(1,2).add(Rational(1,2))` | `1/1` = 1.0 |
| Subtraction | `Rational(1,2).subtract(Rational(1,4))` | `1/4` = 0.25 |
| Multiplication | `Rational(2,3).multiply(Rational(3,4))` | `1/2` = 0.5 |
| Division | `Rational(1,2).divide(Rational(1,4))` | `2/1` = 2.0 |
| Floating-point output | `Rational(1,4).printFloat()` | `0.25` |
