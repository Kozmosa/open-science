#include <iostream>
#include <cstdlib>

int gcd(int a, int b) {
    a = std::abs(a);
    b = std::abs(b);
    while (b != 0) {
        int t = b;
        b = a % b;
        a = t;
    }
    return a == 0 ? 1 : a;
}

class Rational {
public:
    Rational(int num = 0, int den = 1) {
        if (den == 0) den = 1;
        int g = gcd(num, den);
        if (den < 0) { num = -num; den = -den; }
        numerator = num / g;
        denominator = den / g;
    }

    Rational add(const Rational& other) const {
        int num = numerator * other.denominator + other.numerator * denominator;
        int den = denominator * other.denominator;
        return Rational(num, den);
    }

    Rational subtract(const Rational& other) const {
        int num = numerator * other.denominator - other.numerator * denominator;
        int den = denominator * other.denominator;
        return Rational(num, den);
    }

    Rational multiply(const Rational& other) const {
        return Rational(numerator * other.numerator,
                        denominator * other.denominator);
    }

    Rational divide(const Rational& other) const {
        return Rational(numerator * other.denominator,
                        denominator * other.numerator);
    }

    void printFraction() const {
        std::cout << numerator << "/" << denominator;
    }

    void printFloat() const {
        std::cout << static_cast<double>(numerator) / denominator;
    }

private:
    int numerator;
    int denominator;
};

int main() {
    Rational a(1, 2);
    Rational b(2, 4); // should reduce to 1/2
    Rational c(3, 6); // should reduce to 1/2
    Rational d;        // default 0/1

    std::cout << "a = "; a.printFraction(); std::cout << std::endl;
    std::cout << "b = "; b.printFraction(); std::cout << " (reduced from 2/4)" << std::endl;
    std::cout << "c = "; c.printFraction(); std::cout << " (reduced from 3/6)" << std::endl;
    std::cout << "d = "; d.printFraction(); std::cout << std::endl;

    Rational sum = a.add(b);
    std::cout << "1/2 + 1/2 = "; sum.printFraction();
    std::cout << " = "; sum.printFloat(); std::cout << std::endl;

    Rational diff = a.subtract(Rational(1, 4));
    std::cout << "1/2 - 1/4 = "; diff.printFraction();
    std::cout << " = "; diff.printFloat(); std::cout << std::endl;

    Rational prod = Rational(2, 3).multiply(Rational(3, 4));
    std::cout << "2/3 * 3/4 = "; prod.printFraction();
    std::cout << " = "; prod.printFloat(); std::cout << std::endl;

    Rational quot = Rational(1, 2).divide(Rational(1, 4));
    std::cout << "1/2 / 1/4 = "; quot.printFraction();
    std::cout << " = "; quot.printFloat(); std::cout << std::endl;

    Rational big(50, 100);
    std::cout << "50/100 reduced = "; big.printFraction(); std::cout << std::endl;

    return 0;
}
