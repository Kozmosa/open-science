#include <iostream>
#include <vector>

class IntegerSet {
public:
    static const int RANGE = 101;

    IntegerSet() : set(RANGE, false) {}

    IntegerSet(const int arr[], int size) : set(RANGE, false) {
        for (int i = 0; i < size; ++i)
            if (arr[i] >= 0 && arr[i] < RANGE)
                set[arr[i]] = true;
    }

    IntegerSet unionOfSets(const IntegerSet& other) const {
        IntegerSet result;
        for (int i = 0; i < RANGE; ++i)
            result.set[i] = set[i] || other.set[i];
        return result;
    }

    IntegerSet intersectionOfSets(const IntegerSet& other) const {
        IntegerSet result;
        for (int i = 0; i < RANGE; ++i)
            result.set[i] = set[i] && other.set[i];
        return result;
    }

    void insertElement(int k) {
        if (k >= 0 && k < RANGE) set[k] = true;
    }

    void deleteElement(int m) {
        if (m >= 0 && m < RANGE) set[m] = false;
    }

    void printSet() const {
        bool first = true;
        for (int i = 0; i < RANGE; ++i) {
            if (set[i]) {
                if (!first) std::cout << " ";
                std::cout << i;
                first = false;
            }
        }
        if (first) std::cout << "---";
    }

    bool isEqualTo(const IntegerSet& other) const {
        for (int i = 0; i < RANGE; ++i)
            if (set[i] != other.set[i]) return false;
        return true;
    }

private:
    std::vector<bool> set;
};

int main() {
    IntegerSet empty;
    std::cout << "Empty set: ";
    empty.printSet();
    std::cout << std::endl;

    empty.insertElement(5);
    empty.insertElement(10);
    empty.insertElement(100);
    std::cout << "After inserting 5, 10, 100: ";
    empty.printSet();
    std::cout << std::endl;

    empty.deleteElement(10);
    std::cout << "After deleting 10: ";
    empty.printSet();
    std::cout << std::endl;

    int arr1[] = {0, 1, 3, 5, 7, 9};
    int arr2[] = {0, 2, 4, 6, 8, 10, 5, 3};
    IntegerSet set1(arr1, 6);
    IntegerSet set2(arr2, 8);

    std::cout << "set1: ";
    set1.printSet();
    std::cout << std::endl;

    std::cout << "set2: ";
    set2.printSet();
    std::cout << std::endl;

    IntegerSet u = set1.unionOfSets(set2);
    std::cout << "union: ";
    u.printSet();
    std::cout << std::endl;

    IntegerSet inter = set1.intersectionOfSets(set2);
    std::cout << "intersection: ";
    inter.printSet();
    std::cout << std::endl;

    std::cout << std::boolalpha;
    std::cout << "set1 == set2: " << set1.isEqualTo(set2) << std::endl;

    IntegerSet set3(arr1, 6);
    std::cout << "set1 == set3: " << set1.isEqualTo(set3) << std::endl;

    // Test edge: insert out of range
    empty.insertElement(200);
    std::cout << "After trying to insert 200 (out of range): ";
    empty.printSet();
    std::cout << std::endl;

    return 0;
}
