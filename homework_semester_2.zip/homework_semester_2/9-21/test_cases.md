# Test Cases for 9-21 IntegerSet Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Default empty set | `IntegerSet e; e.printSet()` | `---` |
| Insert elements | insert 5, 10, 100 | `5 10 100` |
| Delete element | delete 10 (from {5,10,100}) | `5 100` |
| Insert out of range | insert 200 | no change |
| Array constructor | arr={0,1,3,5,7,9} | `0 1 3 5 7 9` |
| Union | {0,1,3,5,7,9} ∪ {0,2,3,4,5,6,8,10} | `0 1 2 3 4 5 6 7 8 9 10` |
| Intersection | {0,1,3,5,7,9} ∩ {0,2,3,4,5,6,8,10} | `0 3 5` |
| isEqualTo (same) | set1 vs set3 (same init) | `true` |
| isEqualTo (different) | set1 vs set2 | `false` |
