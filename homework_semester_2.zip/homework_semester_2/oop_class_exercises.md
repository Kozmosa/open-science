# Object-Oriented Programming Exercises

## Chapter 9

### 9.5 `Complex` Class

Create a class called `Complex` for performing arithmetic with complex numbers. Write a program to test your class. Complex numbers have the form

```text
realPart + imaginaryPart * i
```

where $i = \sqrt{-1}$.

Use `double` variables to represent the private data of the class. Provide a constructor that enables an object of this class to be initialized when it is declared. The constructor should contain default values in case no initializers are provided. Provide `public` member functions that perform the following tasks:

1. Adding two `Complex` numbers: The real parts are added together and the imaginary parts are added together.
2. Subtracting two `Complex` numbers: The real part of the right operand is subtracted from the real part of the left operand, and the imaginary part of the right operand is subtracted from the imaginary part of the left operand.
3. Printing `Complex` numbers in the form `(a, b)`, where `a` is the real part and `b` is the imaginary part.

### 9.6 `Rational` Class

Create a class called `Rational` for performing arithmetic with fractions. Write a program to test your class. Use integer variables to represent the private data of the class—the numerator and the denominator. Provide a constructor that enables an object of this class to be initialized when it is declared. The constructor should contain default values in case no initializers are provided and should store the fraction in reduced form. For example, the fraction

$$
\frac{2}{4}
$$

would be stored in the object as `1` in the numerator and `2` in the denominator. Provide `public` member functions that perform each of the following tasks:

1. Adding two `Rational` numbers. The result should be stored in reduced form.
2. Subtracting two `Rational` numbers. The result should be stored in reduced form.
3. Multiplying two `Rational` numbers. The result should be stored in reduced form.
4. Dividing two `Rational` numbers. The result should be stored in reduced form.
5. Printing `Rational` numbers in the form `a/b`, where `a` is the numerator and `b` is the denominator.
6. Printing `Rational` numbers in floating-point format.

### 9.11 `Rectangle` Class

Create a class `Rectangle` with attributes `length` and `width`, each of which defaults to `1`. Provide member functions that calculate the perimeter and the area of the rectangle. Also, provide `set` and `get` functions for the `length` and `width` attributes. The `set` functions should verify that `length` and `width` are each floating-point numbers larger than `0.0` and less than `20.0`.

### 9.14 `HugeInteger` Class

Create a class `HugeInteger` that uses a 40-element array of digits to store integers as large as 40 digits each. Provide member functions `input`, `output`, `add` and `subtract`. For comparing `HugeInteger` objects, provide functions `isEqualTo`, `isNotEqualTo`, `isGreaterThan`, `isLessThan`, `isGreaterThanOrEqualTo` and `isLessThanOrEqualTo`—each of these is a “predicate” function that simply returns `true` if the relationship holds between the two `HugeInteger`s and returns `false` if the relationship does not hold. Also, provide a predicate function `isZero`. If you feel ambitious, provide member functions `multiply`, `divide` and `modulus`.

### 9.20 `SavingsAccount` Class

Create a `SavingsAccount` class. Use a `static` data member `annualInterestRate` to store the annual interest rate for each of the savers. Each member of the class contains a private data member `savingsBalance` indicating the amount the saver currently has on deposit. Provide member function `calculateMonthlyInterest` that calculates the monthly interest by multiplying the `savingsBalance` by `annualInterestRate` divided by `12`; this interest should be added to `savingsBalance`. Provide a `static` member function `modifyInterestRate` that sets the `static` `annualInterestRate` to a new value.

Write a driver program to test class `SavingsAccount`. Instantiate two different objects of class `SavingsAccount`, `saver1` and `saver2`, with balances of \$2000.00 and \$3000.00, respectively. Set the `annualInterestRate` to `3` percent. Then calculate the monthly interest and print the new balances for each of the savers. Then set the `annualInterestRate` to `4` percent, calculate the next month’s interest and print the new balances for each of the savers.

### 9.21 `IntegerSet` Class

Create class `IntegerSet` for which each object can hold integers in the range `0` through `100`. Represent the set internally as a `vector` of `bool` values. Element `a[i]` is `true` if integer `i` is in the set. Element `a[j]` is `false` if integer `j` is not in the set. The default constructor initializes a set to the so-called “empty set,” i.e., a set for which all elements contain `false`.

1. Provide member functions for the common set operations. For example, provide a `unionOfSets` member function that creates a third set that is the set-theoretic union of two existing sets (i.e., an element of the result is set to `true` if that element is `true` in either or both of the existing sets, and an element of the result is set to `false` if that element is `false` in each of the existing sets).
2. Provide an `intersectionOfSets` member function which creates a third set which is the set-theoretic intersection of two existing sets (i.e., an element of the result is set to `false` if that element is `false` in either or both of the existing sets, and an element of the result is set to `true` if that element is `true` in each of the existing sets).
3. Provide an `insertElement` member function that places a new integer `k` into a set by setting `a[k]` to `true`. Provide a `deleteElement` member function that deletes integer `m` by setting `a[m]` to `false`.
4. Provide a `printSet` member function that prints a set as a list of numbers separated by spaces. Print only those elements that are present in the set (i.e., their position in the vector has a value of `true`). Print `---` for an empty set.
5. Provide an `isEqualTo` member function that determines whether two sets are equal.
6. Provide an additional constructor that receives an array of integers and the size of that array and uses the array to initialize a set object.

Now write a driver program to test your `IntegerSet` class. Instantiate several `IntegerSet` objects. Test that all your member functions work properly.

## Chapter 10

### 10.10 `RationalNumber` Class

Create a class `RationalNumber` (fractions) with these capabilities:

1. Create a constructor that prevents a `0` denominator in a fraction, reduces or simplifies fractions that are not in reduced form and avoids negative denominators.
2. Overload the addition, subtraction, multiplication and division operators for this class.
3. Overload the relational and equality operators for this class.

### 10.11 `Polynomial` Class

Develop class `Polynomial`. The internal representation of a `Polynomial` is an array of terms. Each term contains a coefficient and an exponent, e.g., the term

$$
2x^4
$$

has the coefficient `2` and the exponent `4`. Develop a complete class containing proper constructor and destructor functions as well as `set` and `get` functions. The class should also provide the following overloaded operator capabilities:

1. Overload the addition operator (`+`) to add two `Polynomial`s.
2. Overload the subtraction operator (`-`) to subtract two `Polynomial`s.
3. Overload the assignment operator (`=`) to assign one `Polynomial` to another.
4. Overload the multiplication operator (`*`) to multiply two `Polynomial`s.
5. Overload the addition assignment operator (`+=`), subtraction assignment operator (`-=`), and multiplication assignment operator (`*=`).

## Chapter 11

### 11.10 Account Inheritance Hierarchy

Create an inheritance hierarchy that a bank might use to represent customers’ bank accounts. All customers at this bank can deposit (i.e., credit) money into their accounts and withdraw (i.e., debit) money from their accounts. More specific types of accounts also exist. Savings accounts, for instance, earn interest on the money they hold. Checking accounts, on the other hand, charge a fee per transaction (i.e., credit or debit).

Create an inheritance hierarchy containing base class `Account` and derived classes `SavingsAccount` and `CheckingAccount` that inherit from class `Account`. Base class `Account` should include one data member of type `double` to represent the account balance. The class should provide a constructor that receives an initial balance and uses it to initialize the data member. The constructor should validate the initial balance to ensure that it’s greater than or equal to `0.0`. If not, the balance should be set to `0.0` and the constructor should display an error message, indicating that the initial balance was invalid.

The class should provide three member functions. Member function `credit` should add an amount to the current balance. Member function `debit` should withdraw money from the `Account` and ensure that the debit amount does not exceed the `Account`’s balance. If it does, the balance should be left unchanged and the function should print the message `Debit amount exceeded account balance.` Member function `getBalance` should return the current balance.

Derived class `SavingsAccount` should inherit the functionality of an `Account`, but also include a data member of type `double` indicating the interest rate (percentage) assigned to the `Account`. `SavingsAccount`’s constructor should receive the initial balance, as well as the initial value for the `SavingsAccount`’s interest rate. `SavingsAccount` should provide a `public` member function `calculateInterest` that returns a `double` indicating the amount of interest earned by an account. Member function `calculateInterest` should determine this amount by multiplying the interest rate by the account balance. **Note:** `SavingsAccount` should inherit member functions `credit` and `debit` as is without redefining them.

Derived class `CheckingAccount` should inherit from base class `Account` and include an additional data member of type `double` that represents the fee charged per transaction. `CheckingAccount`’s constructor should receive the initial balance, as well as a parameter indicating a fee amount. Class `CheckingAccount` should redefine member functions `credit` and `debit` so that they subtract the fee from the account balance whenever either transaction is performed successfully. `CheckingAccount`’s versions of these functions should invoke the base-class `Account` version to perform the updates to an account balance. `CheckingAccount`’s `debit` function should charge a fee only if money is actually withdrawn (i.e., the debit amount does not exceed the account balance). **Hint:** Define `Account`’s `debit` function so that it returns a `bool` indicating whether money was withdrawn. Then use the return value to determine whether a fee should be charged.

After defining the classes in this hierarchy, write a program that creates objects of each class and tests their member functions. Add interest to the `SavingsAccount` object by first invoking its `calculateInterest` function, then passing the returned interest amount to the object’s `credit` function.

## Chapter 12

### 12.14 Polymorphic Banking Program Using Account Hierarchy

Develop a polymorphic banking program using the `Account` hierarchy created in Exercise 11.10. Create a `vector` of `Account` pointers to `SavingsAccount` and `CheckingAccount` objects. For each `Account` in the `vector`, allow the user to specify an amount of money to withdraw from the `Account` using member function `debit` and an amount of money to deposit into the `Account` using member function `credit`. As you process each `Account`, determine its type. If an `Account` is a `SavingsAccount`, calculate the amount of interest owed to the `Account` with member function `calculateInterest`, then add the interest to the account balance using member function `credit`. After processing an `Account`, print the updated account balance obtained by invoking base-class member function `getBalance`.

### 12.15 Payroll System Modification

Modify the payroll system of Figs. 12.9–12.17 to include additional `Employee` subclasses `PieceWorker` and `HourlyWorker`. A `PieceWorker` represents an employee whose pay is based on the number of pieces of merchandise produced. An `HourlyWorker` represents an employee whose pay is based on an hourly wage and the number of hours worked. Hourly workers receive overtime pay (`1.5` times the hourly wage) for all hours worked in excess of `40` hours.

Class `PieceWorker` should contain private instance variables `wage` (to store the employee’s wage per piece) and `pieces` (to store the number of pieces produced). Class `HourlyWorker` should contain private instance variables `wage` (to store the employee’s wage per hour) and `hours` (to store the hours worked). In class `PieceWorker`, provide a concrete implementation of method `earnings` that calculates the employee’s earnings by multiplying the number of pieces produced by the wage per piece. In class `HourlyWorker`, provide a concrete implementation of method `earnings` that calculates the employee’s earnings by multiplying the number of hours worked by the wage per hour. If the number of hours worked is over `40`, be sure to pay the `HourlyWorker` for the overtime hours. Add a pointer to an object of each new class into the `vector` of `Employee` pointers in `main`. For each `Employee`, display its string representation and earnings.
