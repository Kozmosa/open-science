#set page(
  paper: "a4",
  margin: (x: 1.8cm, y: 2cm),
  columns: 2,
  numbering: "1",
)

// ########## 字体设置 ##########
#set text(
  font: "LXGW WenKai",
  size: 10pt,
  lang: "zh",
  hyphenate: false,
)

#show heading.where(level: 1): it => {
  set text(font: "Noto Sans CJK SC", size: 16pt, weight: "semibold")
  block(
    stroke: (bottom: 1.5pt + blue),
    breakable: false,
    [ #v(0.3em, weak: true); #it; #v(0.1em, weak: true) ]
  )
}

#show heading.where(level: 2): it => {
  set text(font: "LXGW WenKai", size: 12pt, weight: "semibold")
  block(
    stroke: (bottom: 0.8pt + gray),
    breakable: false,
    [ #v(0.3em, weak: true); #it; #v(0.1em, weak: true) ]
  )
}

#show heading.where(level: 3): it => {
  set text(font: "LXGW WenKai", size: 10.5pt, weight: "semibold")
  it
}

#show heading.where(level: 3): it => {
  set text(size: 10.5pt, weight: "semibold")
  it
}

// ########## 表格居中 ##########
#show table: it => {
  align(center, it)
}

// ########## 行内代码 ##########
#show raw.where(block: false): it => {
  set text(
    font: ("FiraCode Nerd Font Mono", "LXGW WenKai Mono"),
    size: 9pt,
  )
  box(
    fill: rgb("#eeeeee"),
    inset: (x: 3pt, y: 1pt),
    radius: 2pt,
    baseline: 2pt,
    it
  )
}

// ########## 代码块 ##########
#show raw.where(block: true): it => {
  set text(
    font: ("FiraCode Nerd Font Mono", "LXGW WenKai Mono"),
    size: 8pt,
  )
  block(
    fill: rgb("#f4f4f4"),
    inset: 8pt,
    radius: 3pt,
    width: 100%,
    breakable: true,
    it
  )
}

// ########## 标题 ##########
#align(center, text(size: 20pt, weight: "bold", font: "LXGW WenKai")[
  C++ 面向对象编程核心知识讲义
])

#v(0.8em)

// ########## 正文开始 ##########

= 类与对象基础

== 类的定义

类是 C++ 面向对象编程的核心。一个类将数据（*成员变量*）和操作数据的函数（*成员函数*）封装在一起。

```cpp
class ClassName {
public:
  // 构造函数、成员函数（公有，外部可访问）

private:
  // 成员变量（私有，仅类内部可访问）
};
```

#table(
  columns: (auto, auto),
  stroke: 0.5pt + gray,
  inset: 5pt,
  [*关键字*], [*含义*],
  [`public`], [任何代码均可访问],
  [`private`], [仅类的成员函数和友元可访问],
  [`protected`], [类的成员函数、友元以及派生类可访问],
)

*最佳实践：* 成员变量通常设为 `private`，通过 `public` 成员函数提供受控访问。

== 构造函数

构造函数在对象创建时自动调用，用于初始化成员变量。

```cpp
class Point {
public:
  Point(double x = 0.0, double y = 0.0) : m_x(x), m_y(y) {} // 默认参数

private:
  double m_x, m_y;
};

Point p1;               // 默认值 (0, 0)
Point p2(3.0, 4.0);     // (3, 4)
Point p3(5.0);          // (5, 0)，第二参数使用默认值
```

*初始化列表*（`:` 之后的部分）直接初始化成员变量，比在构造函数体内赋值更高效。对于 `const` 成员和引用成员，必须使用初始化列表。

== const 成员函数

在成员函数后添加 `const` 关键字，表示该函数不会修改任何成员变量：

```cpp
double getX() const { return m_x; }  // 只读
```

`const` 对象只能调用 `const` 成员函数。因此，不修改对象状态的函数都应标记为 `const`。

== 对象的创建与使用

```cpp
Point p(1.0, 2.0);                   // 栈上创建（自动管理生命周期）
Point* ptr = new Point(1.0, 2.0);    // 堆上创建
delete ptr;                          // 手动释放
```

= 函数重载与运算符重载

== 成员函数重载

同一类中可以定义多个同名但参数列表不同的函数：

```cpp
class Printer {
public:
  void print(int x);
  void print(double x);
  void print(const std::string& s);
};
```

== 运算符重载

C++ 允许为自定义类型定义运算符行为。运算符重载可以是*成员函数*或*友元函数*。

*作为成员函数：*

```cpp
class Rational {
public:
  Rational operator+(const Rational& other) const {
    return Rational(num * other.den + other.num * den,
                    den * other.den);
  }
  Rational operator-(const Rational& other) const { /* ... */ }
  Rational operator*(const Rational& other) const { /* ... */ }
  Rational operator/(const Rational& other) const { /* ... */ }

  bool operator==(const Rational& other) const {
    return num == other.num && den == other.den;
  }
  bool operator!=(const Rational& other) const {
    return !(*this == other);     // 复用 ==
  }
  bool operator<(const Rational& other) const {
    return num * other.den < other.num * den;
  }
  // 基于 < 实现其余关系运算
  bool operator>(const Rational& other) const { return other < *this; }
  bool operator<=(const Rational& other) const { return !(*this > other); }
  bool operator>=(const Rational& other) const { return !(*this < other); }

  Rational& operator+=(const Rational& other) {
    *this = *this + other;
    return *this;
  }
};
```

*运算符重载要点：*

- 不可发明的运算符（如 `**`）
- 不可改变运算符的优先级和结合性
- `.` `::` `?:` `sizeof` 不可重载
- `=` 重载时需检查自赋值
- 关系运算符可以相互复用，减少重复代码

== 赋值运算符与拷贝构造函数

当类管理动态内存时，必须遵循*三法则（Rule of Three）*：

```cpp
class DynamicArray {
public:
  DynamicArray(int size) : m_size(size), m_data(new int[size]) {}
  ~DynamicArray() { delete[] m_data; }

  DynamicArray(const DynamicArray& other)
    : m_size(other.m_size), m_data(new int[other.m_size]) {
    for (int i = 0; i < m_size; ++i)
      m_data[i] = other.m_data[i];
  }

  DynamicArray& operator=(const DynamicArray& other) {
    if (this != &other) {          // 防止自赋值
      delete[] m_data;             // 释放旧资源
      m_size = other.m_size;
      m_data = new int[m_size];    // 分配新资源
      for (int i = 0; i < m_size; ++i)
        m_data[i] = other.m_data[i];
    }
    return *this;
  }

private:
  int* m_data;
  int m_size;
};
```

*三法则：* 如果需要自定义析构函数、拷贝构造函数或赋值运算符中的任何一个，通常三者都需要自定义。

= 静态成员

== 静态数据成员

静态数据成员属于*整个类*，而非某个具体对象。所有对象共享同一份数据。

```cpp
class Account {
public:
  static double annualRate;  // 声明
private:
  double balance;
};

double Account::annualRate = 0.03;  // 定义并初始化
```

*关键点：*

- 静态成员在类内声明，在类外定义（通常放在实现文件中）
- 初始化在类外进行，使用 `类型 类名::成员名 = 初始值;` 语法
- 在整个程序生命周期内只有一份拷贝

== 静态成员函数

静态成员函数也不属于任何对象，因此没有 `this` 指针，只能访问静态成员。

```cpp
class Account {
public:
  static void setRate(double r) { annualRate = r; }
  // 静态成员函数只能访问静态成员
};
```

*调用方式：*

```cpp
Account::setRate(0.04);  // 类名调用（推荐）
Account acc;
acc.setRate(0.04);       // 对象调用
```

= 继承

== 基本继承语法

```cpp
class Base {
public:
  Base(int x) : m_base(x) {}
  void baseFunc() {}
private:
  int m_base;
};

class Derived : public Base {  // public 继承
public:
  Derived(int x, int y) : Base(x), m_derived(y) {}
  void derivedFunc() {}
private:
  int m_derived;
};
```

== 继承类型

大多数场景使用 `public` 继承，表达"是一种（is-a）"关系。

#table(
  columns: (auto, auto, auto, auto),
  stroke: 0.5pt + gray,
  inset: 5pt,
  [*继承方式*], [*基类 public*], [*基类 protected*], [*基类 private*],
  [`public`], [保持 public], [保持 protected], [不可访问],
  [`protected`], [变为 protected], [变为 protected], [不可访问],
  [`private`], [变为 private], [变为 private], [不可访问],
)

== 派生类构造函数的职责

派生类构造函数*只负责初始化自己的成员*。基类成员的初始化通过调用基类构造函数完成。初始化列表中先调用 `Base(x)` 初始化基类部分，再初始化 `m_derived(y)` 派生类成员，两者由逗号分隔，顺序不可颠倒。如果不在初始化列表中显式调用基类构造函数，编译器会调用基类的默认构造函数。

如果不在初始化列表中显式调用基类构造函数，编译器会调用基类的默认构造函数。

== 重定义（覆盖）基类成员函数

派生类可以重新定义基类已有的成员函数：

```cpp
class CheckingAccount : public Account {
public:
  void debit(double amount) {
    bool success = Account::debit(amount); // 调用基类版本
    if (success) {
      // 派生类额外操作
    }
  }
};
```

使用 `BaseClassName::functionName()` 来调用被覆盖的基类版本。

= 多态

== 虚函数

多态的核心：通过*基类指针或引用*调用虚函数时，实际执行的是*派生类*的版本。

```cpp
class Animal {
public:
  virtual void speak() const { std::cout << "..."; }
  virtual ~Animal() {}  // 虚析构函数
};

class Dog : public Animal {
public:
  virtual void speak() const override { std::cout << "Woof!"; }
};
```

*使用多态：*

```cpp
std::vector<Animal*> zoo;
zoo.push_back(new Dog());
zoo.push_back(new Cat());

for (Animal* a : zoo)
  a->speak();  // 调用实际类型的版本
```

== 虚析构函数

*基类的析构函数必须声明为虚函数*，否则通过基类指针删除派生类对象时，派生类的析构函数不会被调用，导致内存泄漏：

```cpp
class Base {
public:
  virtual ~Base() {}  // 虚析构函数
};

Base* ptr = new Derived();
// 没有虚析构函数 → Derived::~Derived() 不会被调用
delete ptr;
```

== 纯虚函数与抽象类

纯虚函数使类成为*抽象类*，不能直接实例化：

```cpp
class Shape {
public:
  virtual double area() const = 0;  // 纯虚函数
  virtual ~Shape() {}
};

// Shape s;                        // 错误：不能实例化抽象类
Shape* s = new Circle(5.0);        // 正确：通过指针/引用使用
```

任何包含纯虚函数的类都是抽象类。

== 运行时类型识别

使用 `dynamic_cast` 在运行时安全地将基类指针转换为派生类指针：

```cpp
SavingsAccount* sa = dynamic_cast<SavingsAccount*>(accountPtr);
if (sa != nullptr) {
  double interest = sa->calculateInterest();
}
```

`dynamic_cast` 转换失败时返回 `nullptr`（对于指针），从而可以安全判断对象的实际类型。

== override 关键字（C++11）

`override` 明确声明函数意图覆盖基类虚函数，编译器会检查签名是否匹配：

```cpp
class Derived : public Base {
public:
  virtual void speak() const override; // 基类无此函数则编译报错
};
```

= STL 容器

== std::vector

动态数组，大小可运行时调整。

```cpp
#include <vector>

std::vector<int> v;            // 空向量
std::vector<int> v2(10);       // 10 个元素，默认值 0
std::vector<int> v3(10, 42);   // 10 个元素，每个为 42

v.push_back(5);                // 在末尾添加
v.pop_back();                  // 删除末尾
v.size();                      // 元素个数
v[0] = 10;                     // 下标访问（不检查边界）
v.at(0) = 10;                  // 边界检查访问（越界抛异常）
```

== std::vector\<bool\>

`std::vector<bool>` 是 `std::vector` 对 `bool` 类型的特化版本，内部使用位压缩存储以节省空间。

```cpp
std::vector<bool> flags(100, false);
flags[5] = true;
flags[10] = true;

if (flags[5]) {  // 元素 5 为 true
}
```

*注意：* `vector<bool>` 不返回 `bool&` 引用，而返回代理对象。大多数使用场景中，行为与普通 `vector` 一致。

== 存储多态对象

将基类指针存储在 `vector` 中是多态的常见用法：

```cpp
std::vector<Base*> items;
items.push_back(new Derived1());
items.push_back(new Derived2());

for (Base* item : items)      // 释放内存
  delete item;
```

C++11 也可使用智能指针简化内存管理：

```cpp
#include <memory>
std::vector<std::unique_ptr<Base>> items;
items.push_back(std::unique_ptr<Base>(new Derived1()));
// 自动释放，无需手动 delete
```

= 输入输出

== 格式化输出

使用 `<iomanip>` 控制浮点数输出格式：

```cpp
#include <iostream>
#include <iomanip>

double pi = 3.1415926;

// 固定小数点，保留两位 → 输出 3.14
std::cout << std::fixed << std::setprecision(2) << pi;

// bool 以 true/false 显示 → 输出 true
std::cout << std::boolalpha << (3 > 1);
```

*常用格式化操纵符：*

#table(
  columns: (auto, auto),
  stroke: 0.5pt + gray,
  inset: 5pt,
  [*操纵符*], [*效果*],
  [`std::fixed`], [固定小数点表示],
  [`std::scientific`], [科学计数法],
  [`std::setprecision(n)`], [设置精度],
  [`std::setw(n)`], [设置字段宽度],
  [`std::boolalpha`], [bool 输出为 true/false],
  [`std::left` / `std::right`], [左/右对齐],
)

== 字符串流

使用 `<sstream>` 在内存中构建格式化字符串：

```cpp
#include <sstream>

std::ostringstream oss;
oss << std::fixed << std::setprecision(2) << 12.5;
std::string result = oss.str();  // "12.50"
```

== 数值与字符串的转换（C++11）

```cpp
std::string s = std::to_string(42);   // "42"（数值→字符串）
std::string s2 = std::to_string(3.14); // "3.140000"

int n = std::stoi("42");              // 字符串→int
double d = std::stod("3.14");         // 字符串→double
```

= 常用算法与编程技巧

== 最大公约数（GCD）

欧几里得算法用于约分分数：

```cpp
int gcd(int a, int b) {
  a = std::abs(a);
  b = std::abs(b);
  while (b != 0) {
    int t = b;
    b = a % b;
    a = t;
  }
  return a == 0 ? 1 : a;  // 返回 1 防止除以零
}
```

== 大数运算

当整数超出内置类型范围时，使用*数组或向量存储每一位数字*，模拟手工运算：

- *加法：* 从低位到高位逐位相加，处理进位（carry）
- *减法：* 逐位相减，处理借位（borrow）
- *比较：* 从高位向低位逐位比较

```cpp
// 大数加法（digits[0] 存储最低位）
int carry = 0;
for (int i = 0; i < SIZE; ++i) {
  int sum = a[i] + b[i] + carry;
  result[i] = sum % 10;
  carry = sum / 10;
}
```

== 多项式运算

*加法/减法：* 合并同类项（相同指数的项系数相加/减）

*乘法：* 每一项与另一多项式的每一项相乘，将结果中相同指数的项合并：

$ (A_1 x^a + A_2 x^b) times (B_1 x^c + B_2 x^d) \
  = A_1 B_1 x^(a+c) \
  + A_1 B_2 x^(a+d) \
  + A_2 B_1 x^(b+c) \
  + A_2 B_2 x^(b+d) $

实现时需维护按指数排序的项列表，乘法完成后合并相同指数。

== 分数运算

所有分数运算后必须*约分*（分子分母同除以最大公约数），并处理*分母符号*（分母不得为负）：

```cpp
void normalize(int& num, int& den) {
  int g = gcd(num, den);
  num /= g;
  den /= g;
  if (den < 0) { num = -num; den = -den; }
}
```

*算术运算公式：*

#table(
  columns: (auto, auto),
  stroke: 0.5pt + gray,
  inset: 5pt,
  [*运算*], [*公式*],
  [加法], [$ a/b + c/d = (a d + b c)/(b d) $],
  [减法], [$ a/b - c/d = (a d - b c)/(b d) $],
  [乘法], [$ a/b times c/d = (a c)/(b d) $],
  [除法], [$ a/b \/ c/d = (a d)/(b c) $],
)

== 复利计算

月利息 = 本金 × 年利率 / 12：

```cpp
balance += balance * annualRate / 12.0;
```

= 内存管理与安全

== 栈与堆

#table(
  columns: (auto, auto, auto),
  stroke: 0.5pt + gray,
  inset: 5pt,
  [*特性*], [*栈（Stack）*], [*堆（Heap）*],
  [分配], [自动], [`new` / `new[]`],
  [释放], [自动（离开作用域）], [`delete` / `delete[]`],
  [速度], [快], [较慢],
  [大小], [有限], [较大],
)

== new 和 delete 配对规则

```cpp
int* p1 = new int;         delete p1;     // new → delete
int* p2 = new int[10];     delete[] p2;   // new[] → delete[]
```

配对错误导致*未定义行为*。

== 避免内存泄漏

- *三法则：* 管理动态内存的类必须正确实现析构、拷贝构造、赋值
- *使用容器：* 优先用 `std::vector` / `std::string` 替代原始数组
- *使用智能指针：* C++11 引入 `std::unique_ptr` / `std::shared_ptr`

```cpp
int* arr = new int[100];                 // 不推荐：需手动 delete
std::vector<int> arr(100);               // 推荐：自动释放
std::unique_ptr<int[]> arr(new int[100]);// 推荐：C++11 智能指针
```

= C++11 关键特性速查

#table(
  columns: (auto, auto),
  stroke: 0.5pt + gray,
  inset: 5pt,
  [*特性*], [*用法*],
  [`override`], [明确标注虚函数覆盖],
  [`nullptr`], [空指针常量，替代 `NULL`],
  [`auto`], [类型自动推导],
  [范围 for], [`for (auto& x : vec)`],
  [`std::to_string`], [数值转字符串],
  [`std::stoi` / `std::stod`], [字符串转数值],
  [`std::vector::data()`], [获取底层数组指针],
)

= 常见编译错误与解决方案

#table(
  columns: (auto, auto, auto),
  stroke: 0.5pt + gray,
  inset: 5pt,
  [*错误信息*], [*原因*], [*解决*],
  [`undefined reference to`], [链接时找不到函数定义], [检查 .cpp 文件是否一起编译],
  [`incomplete type`], [类型未定义], [检查头文件是否包含],
  [`no matching function`], [函数签名不匹配], [检查参数类型和数量],
  [`static linkage`], [静态成员函数声明有误], [类内声明用 `static`，类外定义不用],
  [`not declared in scope`], [标识符未声明], [检查拼写、包含头文件、声明顺序],
  [`undefined reference to vtable`], [虚函数声明但未定义], [为所有虚函数提供定义],
  [`pure virtual function call`], [调用了纯虚函数], [构造/析构函数中不要调用纯虚函数],
)
