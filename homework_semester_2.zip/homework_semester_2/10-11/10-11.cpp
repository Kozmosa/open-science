#include <iostream>

class Polynomial {
public:
    Polynomial() : terms(0), termCount(0) {}

    Polynomial(const Polynomial& other) : terms(0), termCount(0) {
        copyFrom(other);
    }

    ~Polynomial() {
        delete[] terms;
    }

    Polynomial& operator=(const Polynomial& other) {
        if (this != &other) {
            delete[] terms;
            copyFrom(other);
        }
        return *this;
    }

    void setTerm(int coeff, int exp) {
        if (coeff == 0) {
            removeTerm(exp);
            return;
        }
        for (int i = 0; i < termCount; ++i) {
            if (terms[i].exponent == exp) {
                terms[i].coefficient = coeff;
                return;
            }
        }
        insertTerm(coeff, exp);
    }

    int getCoefficient(int exp) const {
        for (int i = 0; i < termCount; ++i)
            if (terms[i].exponent == exp)
                return terms[i].coefficient;
        return 0;
    }

    Polynomial operator+(const Polynomial& other) const {
        Polynomial result(*this);
        for (int i = 0; i < other.termCount; ++i)
            result.addTerm(other.terms[i].coefficient, other.terms[i].exponent);
        return result;
    }

    Polynomial operator-(const Polynomial& other) const {
        Polynomial result(*this);
        for (int i = 0; i < other.termCount; ++i)
            result.addTerm(-other.terms[i].coefficient, other.terms[i].exponent);
        return result;
    }

    Polynomial operator*(const Polynomial& other) const {
        Polynomial result;
        for (int i = 0; i < termCount; ++i) {
            for (int j = 0; j < other.termCount; ++j) {
                int c = terms[i].coefficient * other.terms[j].coefficient;
                int e = terms[i].exponent + other.terms[j].exponent;
                result.addTerm(c, e);
            }
        }
        return result;
    }

    Polynomial& operator+=(const Polynomial& other) {
        *this = *this + other;
        return *this;
    }

    Polynomial& operator-=(const Polynomial& other) {
        *this = *this - other;
        return *this;
    }

    Polynomial& operator*=(const Polynomial& other) {
        *this = *this * other;
        return *this;
    }

    void print() const {
        if (termCount == 0) {
            std::cout << "0";
            return;
        }
        for (int i = 0; i < termCount; ++i) {
            int c = terms[i].coefficient;
            int e = terms[i].exponent;
            if (i > 0 && c > 0) std::cout << " + ";
            if (c < 0) { std::cout << " - "; c = -c; }
            std::cout << c;
            if (e > 0) {
                std::cout << "x";
                if (e > 1) std::cout << "^" << e;
            }
        }
    }

private:
    struct Term {
        int coefficient;
        int exponent;
    };

    Term* terms;
    int termCount;

    void copyFrom(const Polynomial& other) {
        termCount = other.termCount;
        terms = new Term[termCount];
        for (int i = 0; i < termCount; ++i)
            terms[i] = other.terms[i];
    }

    void addTerm(int coeff, int exp) {
        for (int i = 0; i < termCount; ++i) {
            if (terms[i].exponent == exp) {
                terms[i].coefficient += coeff;
                if (terms[i].coefficient == 0) removeTermAt(i);
                return;
            }
        }
        if (coeff != 0) insertTerm(coeff, exp);
    }

    void insertTerm(int coeff, int exp) {
        Term* newTerms = new Term[termCount + 1];
        int pos = 0;
        while (pos < termCount && terms[pos].exponent > exp) ++pos;
        for (int i = 0; i < pos; ++i)
            newTerms[i] = terms[i];
        newTerms[pos].coefficient = coeff;
        newTerms[pos].exponent = exp;
        for (int i = pos; i < termCount; ++i)
            newTerms[i + 1] = terms[i];
        delete[] terms;
        terms = newTerms;
        ++termCount;
    }

    void removeTerm(int exp) {
        for (int i = 0; i < termCount; ++i) {
            if (terms[i].exponent == exp) {
                removeTermAt(i);
                return;
            }
        }
    }

    void removeTermAt(int index) {
        Term* newTerms = new Term[termCount - 1];
        for (int i = 0; i < index; ++i)
            newTerms[i] = terms[i];
        for (int i = index + 1; i < termCount; ++i)
            newTerms[i - 1] = terms[i];
        delete[] terms;
        terms = newTerms;
        --termCount;
    }
};

int main() {
    Polynomial p1;
    p1.setTerm(2, 4);  // 2x^4
    p1.setTerm(3, 2);  // 3x^2
    p1.setTerm(1, 0);  // 1

    Polynomial p2;
    p2.setTerm(1, 3);  // x^3
    p2.setTerm(4, 2);  // 4x^2
    p2.setTerm(5, 0);  // 5

    std::cout << "p1 = "; p1.print(); std::cout << std::endl;
    std::cout << "p2 = "; p2.print(); std::cout << std::endl;

    Polynomial sum = p1 + p2;
    std::cout << "p1 + p2 = "; sum.print(); std::cout << std::endl;

    Polynomial diff = p1 - p2;
    std::cout << "p1 - p2 = "; diff.print(); std::cout << std::endl;

    Polynomial prod = p1 * p2;
    std::cout << "p1 * p2 = "; prod.print(); std::cout << std::endl;

    // Test assignment
    Polynomial p3 = p1;
    std::cout << "p3 (copy of p1) = "; p3.print(); std::cout << std::endl;

    // Test +=
    p3 += p2;
    std::cout << "p3 += p2 → "; p3.print(); std::cout << std::endl;

    // Test -=
    Polynomial p4 = p1;
    p4 -= p2;
    std::cout << "p4 (p1) -= p2 → "; p4.print(); std::cout << std::endl;

    // Test *=
    Polynomial p5 = p1;
    Polynomial scalar; scalar.setTerm(2, 0); // p5 = p5 * 2
    p5 *= scalar;
    std::cout << "p1 * 2 = "; p5.print(); std::cout << std::endl;

    // Test get
    std::cout << "Coefficient of x^2 in p1: " << p1.getCoefficient(2) << std::endl;
    std::cout << "Coefficient of x^5 in p1: " << p1.getCoefficient(5) << " (absent)" << std::endl;

    // Test zero polynomial
    Polynomial zero;
    std::cout << "zero = "; zero.print(); std::cout << std::endl;

    return 0;
}
