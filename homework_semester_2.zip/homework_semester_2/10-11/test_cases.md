# Test Cases for 10-11 Polynomial Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Empty polynomial | `Polynomial z; z.print()` | `0` |
| Set/get term | setTerm(2,4), getCoefficient(4) | `2` |
| Absent term | getCoefficient(5) on p1 | `0` |
| Addition | (2x^4+3x^2+1) + (x^3+4x^2+5) | `2x^4 + x^3 + 7x^2 + 6` |
| Subtraction | (2x^4+3x^2+1) - (x^3+4x^2+5) | `2x^4 - x^3 - x^2 - 4` |
| Multiplication | (2x^4+3x^2+1) * (x^3+4x^2+5) | `2x^7+8x^6+3x^5+22x^4+x^3+19x^2+5` |
| Copy/assignment | `Polynomial p3 = p1` | Same as p1 |
| += operator | p3 += p2 | p3 = p1 + p2 |
| -= operator | p4 -= p2 | p4 = p1 - p2 |
| *= operator | p1 *= 2 (via scalar) | 4x^4 + 6x^2 + 2 |
| Multiply by zero | p1 * zero | 0 |
