# C++ 面向对象编程核心知识讲义

---

## 第一章：类与对象基础

### 1.1 类的定义

类是 C++ 面向对象编程的核心。一个类将数据（**成员变量**）和操作数据的函数（**成员函数**）封装在一起。

```cpp
class ClassName {
public:     // 公有成员，外部可访问
    // 构造函数
    // 成员函数

private:    // 私有成员，仅类内部可访问
    // 成员变量
};
```

**访问控制符：**

| 关键字 | 含义 |
|--------|------|
| `public` | 任何代码均可访问 |
| `private` | 仅类的成员函数和友元可访问 |
| `protected` | 类的成员函数、友元以及派生类可访问 |

**最佳实践：** 成员变量通常设为 `private`，通过 `public` 成员函数提供受控访问。

### 1.2 构造函数

构造函数在对象创建时自动调用，用于初始化成员变量。

```cpp
class Point {
public:
    // 带默认参数的构造函数
    Point(double x = 0.0, double y = 0.0) : m_x(x), m_y(y) {}

private:
    double m_x, m_y;
};

// 使用方式
Point p1;           // 使用默认值 (0, 0)
Point p2(3.0, 4.0); // (3, 4)
Point p3(5.0);      // (5, 0)，第二个参数使用默认值
```

**初始化列表**（`:` 之后的部分）直接初始化成员变量，比在构造函数体内赋值更高效。对于 `const` 成员和引用成员，必须使用初始化列表。

### 1.3 const 成员函数

在成员函数后添加 `const` 关键字，表示该函数不会修改任何成员变量：

```cpp
double getX() const { return m_x; }  // 正确：只读操作
```

`const` 对象只能调用 `const` 成员函数。因此，不修改对象状态的函数都应标记为 `const`。

### 1.4 对象的创建与使用

```cpp
// 栈上创建（自动管理生命周期）
Point p(1.0, 2.0);

// 堆上创建（需手动释放）
Point* ptr = new Point(1.0, 2.0);
delete ptr;
```

---

## 第二章：函数重载与运算符重载

### 2.1 成员函数重载

同一类中可以定义多个同名但参数列表不同的函数：

```cpp
class Printer {
public:
    void print(int x);
    void print(double x);
    void print(const std::string& s);
};
```

### 2.2 运算符重载

C++ 允许为自定义类型定义运算符行为。运算符重载可以是**成员函数**或**友元函数**。

**作为成员函数：**

```cpp
class Rational {
public:
    // 算术运算符
    Rational operator+(const Rational& other) const {
        return Rational(num * other.den + other.num * den,
                        den * other.den);
    }

    Rational operator-(const Rational& other) const { /* ... */ }
    Rational operator*(const Rational& other) const { /* ... */ }
    Rational operator/(const Rational& other) const { /* ... */ }

    // 关系运算符
    bool operator==(const Rational& other) const {
        return num == other.num && den == other.den;
    }

    bool operator!=(const Rational& other) const {
        return !(*this == other);  // 复用 ==
    }

    bool operator<(const Rational& other) const {
        return num * other.den < other.num * den;
    }

    // 基于 < 实现其余关系运算符
    bool operator>(const Rational& other) const { return other < *this; }
    bool operator<=(const Rational& other) const { return !(*this > other); }
    bool operator>=(const Rational& other) const { return !(*this < other); }

    // 复合赋值运算符
    Rational& operator+=(const Rational& other) {
        *this = *this + other;
        return *this;
    }
};
```

**运算符重载要点：**
- 不可发明的运算符（如 `**`）
- 不可改变运算符的优先级和结合性
- `.` `::` `?:` `sizeof` 不可重载
- `=` 重载时需检查自赋值
- 关系运算符可以相互复用，减少重复代码

### 2.3 赋值运算符与拷贝构造函数

当类管理动态内存时，必须遵循**三法则（Rule of Three）**：

```cpp
class DynamicArray {
public:
    // 构造函数
    DynamicArray(int size) : m_size(size), m_data(new int[size]) {}

    // 析构函数
    ~DynamicArray() { delete[] m_data; }

    // 拷贝构造函数
    DynamicArray(const DynamicArray& other)
        : m_size(other.m_size), m_data(new int[other.m_size]) {
        for (int i = 0; i < m_size; ++i)
            m_data[i] = other.m_data[i];
    }

    // 赋值运算符
    DynamicArray& operator=(const DynamicArray& other) {
        if (this != &other) {          // 防止自赋值
            delete[] m_data;            // 释放旧资源
            m_size = other.m_size;
            m_data = new int[m_size];   // 分配新资源
            for (int i = 0; i < m_size; ++i)
                m_data[i] = other.m_data[i];
        }
        return *this;
    }

private:
    int* m_data;
    int m_size;
};
```

**三法则：** 如果需要自定义析构函数、拷贝构造函数或赋值运算符中的任何一个，通常三者都需要自定义。

---

## 第三章：静态成员

### 3.1 静态数据成员

静态数据成员属于**整个类**，而非某个具体对象。所有对象共享同一份数据。

```cpp
class Account {
public:
    static double annualRate;  // 声明（不可在此初始化）
private:
    double balance;
};

// 定义并初始化（放在 .cpp 文件中）
double Account::annualRate = 0.03;
```

**关键点：**
- 静态成员在类内声明，在类外定义（通常放在实现文件中）
- 初始化在类外进行，使用 `类型 类名::成员名 = 初始值;` 语法
- 在整个程序生命周期内只有一份拷贝

### 3.2 静态成员函数

静态成员函数也不属于任何对象，因此没有 `this` 指针，只能访问静态成员。

```cpp
class Account {
public:
    static void setRate(double r) { annualRate = r; }
    // 静态成员函数只能访问静态成员
};
```

**调用方式：**
```cpp
Account::setRate(0.04);            // 通过类名调用（推荐）
Account acc;
acc.setRate(0.04);                 // 也可以通过对象调用
```

---

## 第四章：继承

### 4.1 基本继承语法

```cpp
class Base {
public:
    Base(int x) : m_base(x) {}
    void baseFunc() {}
private:
    int m_base;
};

class Derived : public Base {   // public 继承
public:
    // 派生类构造函数需调用基类构造函数
    Derived(int x, int y) : Base(x), m_derived(y) {}
    void derivedFunc() {}
private:
    int m_derived;
};
```

### 4.2 继承类型

| 继承方式 | 基类 public 成员 | 基类 protected 成员 | 基类 private 成员 |
|----------|-----------------|--------------------|--------------------|
| `public` | 保持 public | 保持 protected | 不可访问 |
| `protected` | 变为 protected | 变为 protected | 不可访问 |
| `private` | 变为 private | 变为 private | 不可访问 |

绝大多数场景使用 `public` 继承，表达"是一种（is-a）"关系。

### 4.3 派生类构造函数的职责

派生类构造函数**只负责初始化自己的成员**。基类成员的初始化通过调用基类构造函数完成：

```cpp
Derived(int x, int y) : Base(x), m_derived(y) {}
//                       ^^^^^^^^    ^^^^^^^^^^^^^^
//                       基类构造    派生类成员初始化
```

如果不在初始化列表中显式调用基类构造函数，编译器会调用基类的默认构造函数。

### 4.4 重定义（覆盖）基类成员函数

派生类可以重新定义基类已有的成员函数：

```cpp
class CheckingAccount : public Account {
public:
    void debit(double amount) {
        // 调用基类版本完成基本操作
        bool success = Account::debit(amount);
        if (success) {
            // 派生类的额外操作
        }
    }
};
```

使用 `BaseClassName::functionName()` 来调用被覆盖的基类版本。

---

## 第五章：多态

### 5.1 虚函数

多态的核心：通过**基类指针或引用**调用虚函数时，实际执行的是**派生类**的版本。

```cpp
class Animal {
public:
    virtual void speak() const { std::cout << "..."; }
    virtual ~Animal() {}  // 虚析构函数（重要！）
};

class Dog : public Animal {
public:
    virtual void speak() const { std::cout << "Woof!"; }
    // C++11 中建议使用 override 关键字：
    // virtual void speak() const override { std::cout << "Woof!"; }
};
```

**使用多态：**

```cpp
std::vector<Animal*> zoo;
zoo.push_back(new Dog());
zoo.push_back(new Cat());

for (Animal* a : zoo) {
    a->speak();  // 调用实际类型的版本
}
```

### 5.2 虚析构函数

**基类的析构函数必须声明为虚函数**，否则通过基类指针删除派生类对象时，派生类的析构函数不会被调用，导致内存泄漏：

```cpp
class Base {
public:
    virtual ~Base() {}  // 关键：虚析构函数
};

Base* ptr = new Derived();
delete ptr;  // 如果没有虚析构函数，Derived::~Derived() 不会被调用！
```

### 5.3 纯虚函数与抽象类

纯虚函数使类成为**抽象类**，不能直接实例化：

```cpp
class Shape {
public:
    virtual double area() const = 0;  // 纯虚函数
    virtual ~Shape() {}
};

// Shape s;     // 错误！不能实例化抽象类
Shape* s = new Circle(5.0);  // 正确：通过指针/引用使用
```

任何包含纯虚函数的类都是抽象类。

### 5.4 运行时类型识别

使用 `dynamic_cast` 在运行时安全地将基类指针转换为派生类指针：

```cpp
SavingsAccount* sa = dynamic_cast<SavingsAccount*>(accountPtr);
if (sa != nullptr) {
    // accountPtr 确实指向 SavingsAccount 对象
    double interest = sa->calculateInterest();
}
```

`dynamic_cast` 转换失败时返回 `nullptr`（对于指针），从而可以安全判断对象的实际类型。

### 5.5 override 关键字（C++11）

`override` 明确声明函数意图覆盖基类虚函数，编译器会检查签名是否匹配：

```cpp
class Derived : public Base {
public:
    virtual void speak() const override;  // 如果基类没有此虚函数，编译报错
};
```

---

## 第六章：STL 容器

### 6.1 std::vector

动态数组，大小可运行时调整。

```cpp
#include <vector>

std::vector<int> v;           // 空向量
std::vector<int> v2(10);      // 10 个元素，默认值 0
std::vector<int> v3(10, 42);  // 10 个元素，每个值为 42

v.push_back(5);               // 在末尾添加元素
v.pop_back();                 // 删除末尾元素
v.size();                     // 当前元素个数
v[0] = 10;                    // 通过下标访问（不检查边界）
v.at(0) = 10;                 // 通过下标访问（检查边界，越界抛出异常）
```

### 6.2 std::vector\<bool\>

`std::vector<bool>` 是 `std::vector` 对 `bool` 类型的特化版本，内部使用位压缩存储以节省空间。

```cpp
std::vector<bool> flags(100, false);
flags[5] = true;
flags[10] = true;

if (flags[5]) {
    // 元素 5 为 true
}
```

**注意：** `vector<bool>` 不返回 `bool&` 引用，而返回代理对象。大多数使用场景中，行为与普通 `vector` 一致。

### 6.3 存储多态对象

将基类指针存储在 `vector` 中是多态的常见用法：

```cpp
std::vector<Base*> items;
items.push_back(new Derived1());
items.push_back(new Derived2());

// 使用完毕后释放内存
for (Base* item : items)
    delete item;
```

C++11 也可使用智能指针简化内存管理：

```cpp
#include <memory>
std::vector<std::unique_ptr<Base>> items;
items.push_back(std::unique_ptr<Base>(new Derived1()));
// 自动释放，无需手动 delete
```

---

## 第七章：输入输出

### 7.1 格式化输出

使用 `<iomanip>` 控制浮点数输出格式：

```cpp
#include <iostream>
#include <iomanip>

double pi = 3.1415926;

// 固定小数点，保留两位
std::cout << std::fixed << std::setprecision(2) << pi;
// 输出: 3.14

// bool 值以 true/false 显示
std::cout << std::boolalpha << (3 > 1);
// 输出: true
```

**常用格式化操纵符：**

| 操纵符 | 效果 |
|--------|------|
| `std::fixed` | 固定小数点表示 |
| `std::scientific` | 科学计数法 |
| `std::setprecision(n)` | 设置精度 |
| `std::setw(n)` | 设置字段宽度 |
| `std::boolalpha` | bool 输出为 true/false |
| `std::left` / `std::right` | 左/右对齐 |

### 7.2 字符串流

使用 `<sstream>` 在内存中构建格式化字符串：

```cpp
#include <sstream>

std::ostringstream oss;
oss << std::fixed << std::setprecision(2) << 12.5;
std::string result = oss.str();  // "12.50"
```

### 7.3 数值与字符串的转换（C++11）

```cpp
// 数值转字符串
std::string s = std::to_string(42);       // "42"
std::string s2 = std::to_string(3.14);     // "3.140000"

// 字符串转数值
int n = std::stoi("42");
double d = std::stod("3.14");
```

---

## 第八章：常用算法与编程技巧

### 8.1 最大公约数（GCD）

欧几里得算法用于约分分数：

```cpp
int gcd(int a, int b) {
    a = std::abs(a);
    b = std::abs(b);
    while (b != 0) {
        int t = b;
        b = a % b;
        a = t;
    }
    return a == 0 ? 1 : a;  // 返回 1 而非 0，防止除以零
}
```

### 8.2 大数运算

当整数超出内置类型范围时，使用**数组或向量存储每一位数字**，模拟手工运算：

- **加法：** 从低位到高位逐位相加，处理进位（carry）
- **减法：** 逐位相减，处理借位（borrow）
- **比较：** 从高位向低位逐位比较

```cpp
// 大数加法核心逻辑（digits[0] 存储最低位）
int carry = 0;
for (int i = 0; i < SIZE; ++i) {
    int sum = a[i] + b[i] + carry;
    result[i] = sum % 10;
    carry = sum / 10;
}
```

### 8.3 多项式运算

**加法/减法：** 合并同类项（相同指数的项系数相加/减）

**乘法：** 每一项与另一多项式的每一项相乘，将结果中相同指数的项合并：

```
(A₁xᵃ + A₂xᵇ) × (B₁xᶜ + B₂xᵈ) = A₁B₁xᵃ⁺ᶜ + A₁B₂xᵃ⁺ᵈ + A₂B₁xᵇ⁺ᶜ + A₂B₂xᵇ⁺ᵈ
```

实现时需维护按指数排序的项列表，乘法完成后合并相同指数。

### 8.4 分数运算

所有分数运算后必须**约分**（分子分母同除以最大公约数），并处理**分母符号**（分母不得为负）：

```cpp
void normalize(int& num, int& den) {
    int g = gcd(num, den);
    num /= g;
    den /= g;
    if (den < 0) { num = -num; den = -den; }
}
```

算术运算公式：

| 运算 | 公式 |
|------|------|
| 加法 | `a/b + c/d = (ad + bc) / bd` |
| 减法 | `a/b - c/d = (ad - bc) / bd` |
| 乘法 | `a/b × c/d = ac / bd` |
| 除法 | `a/b ÷ c/d = ad / bc` |

### 8.5 复利计算

月利息 = 本金 × 年利率 / 12：

```cpp
balance += balance * annualRate / 12.0;
```

---

## 第九章：内存管理与安全

### 9.1 栈与堆

| 特性 | 栈（Stack） | 堆（Heap） |
|------|------------|-----------|
| 分配 | 自动 | `new` / `new[]` |
| 释放 | 自动（离开作用域） | `delete` / `delete[]` |
| 速度 | 快 | 较慢 |
| 大小 | 有限 | 较大 |

### 9.2 new 和 delete 配对规则

```cpp
int* p1 = new int;        delete p1;     // new 对应 delete
int* p2 = new int[10];    delete[] p2;   // new[] 对应 delete[]
```

配对错误导致**未定义行为**。

### 9.3 避免内存泄漏

- **三法则：** 管理动态内存的类必须正确实现析构、拷贝构造、赋值
- **使用容器：** 优先用 `std::vector` / `std::string` 替代原始数组
- **使用智能指针：** C++11 引入 `std::unique_ptr` / `std::shared_ptr`

```cpp
// 不推荐：原始指针，需手动 delete
int* arr = new int[100];

// 推荐：使用 vector
std::vector<int> arr(100);  // 自动释放

// 推荐：使用 unique_ptr（C++11）
std::unique_ptr<int[]> arr(new int[100]);  // 自动释放
```

---

## 第十章：C++11 关键特性速查

| 特性 | 用法 |
|------|------|
| `override` | 明确标注虚函数覆盖 |
| `nullptr` | 空指针常量，替代 `NULL` |
| `auto` | 类型自动推导 |
| 范围 for | `for (auto& x : vec)` |
| `std::to_string` | 数值转字符串 |
| `std::stoi` / `std::stod` | 字符串转数值 |
| `std::vector::data()` | 获取底层数组指针 |

---

## 附录：常见编译错误与解决方案

| 错误信息 | 原因 | 解决 |
|----------|------|------|
| `undefined reference to` | 链接时找不到函数定义 | 检查 .cpp 文件是否一起编译 |
| `variable has initializer but incomplete type` | 类型未定义 | 检查头文件是否包含 |
| `no matching function for call` | 函数签名不匹配 | 检查参数类型和数量 |
| `cannot declare member function ... to have static linkage` | 静态成员函数在类内定义但使用了 static 关键字 | 类内声明用 `static`，类外定义不用 |
| `was not declared in this scope` | 使用未声明的标识符 | 检查拼写、包含头文件、声明顺序 |
| `undefined reference to vtable` | 虚函数声明但未定义 | 为所有虚函数提供定义（即使是空的） |
| `pure virtual function call` | 调用了纯虚函数 | 构造函数/析构函数中不要调用纯虚函数 |

---

> 本讲义覆盖了 C++ 面向对象编程的核心知识，包括类与对象、运算符重载、静态成员、继承、多态、STL 容器、I/O 格式化以及常用算法技巧。掌握这些内容后，可以胜任大多数本科级别的 OOP 编程任务。
