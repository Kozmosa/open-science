# Test Cases for 10-10 RationalNumber Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Constructor reduces | `RationalNumber(2, 4)` | `1/2` |
| Constructor avoids negative denom | `RationalNumber(1, -3)` | `-1/3` |
| Constructor prevents zero denom | `RationalNumber(5, 0)` | `5/1` (denom set to 1) |
| Default constructor | `RationalNumber c;` | `0/1` |
| Addition | `1/2 + 1/4` | `3/4` = 0.75 |
| Subtraction | `1/2 - 1/4` | `1/4` = 0.25 |
| Multiplication | `2/3 * 3/4` | `1/2` = 0.5 |
| Division | `1/2 / 1/4` | `2/1` = 2.0 |
| == operator | `1/2 == 2/4` | `true` |
| != operator | `1/2 != 0/1` | `true` |
| < operator | `0/1 < 1/2` | `true` |
| > operator | `1/2 > 0/1` | `true` |
| <= operator | `1/2 <= 2/4` | `true` |
| >= operator | `1/2 >= 2/4` | `true` |
