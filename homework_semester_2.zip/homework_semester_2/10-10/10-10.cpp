#include <iostream>
#include <cstdlib>

int gcd(int a, int b) {
    a = std::abs(a);
    b = std::abs(b);
    while (b != 0) {
        int t = b;
        b = a % b;
        a = t;
    }
    return a == 0 ? 1 : a;
}

class RationalNumber {
public:
    RationalNumber(int num = 0, int den = 1) {
        if (den == 0) den = 1;
        int g = gcd(num, den);
        num /= g;
        den /= g;
        if (den < 0) { num = -num; den = -den; }
        numerator = num;
        denominator = den;
    }

    RationalNumber operator+(const RationalNumber& other) const {
        return RationalNumber(
            numerator * other.denominator + other.numerator * denominator,
            denominator * other.denominator);
    }

    RationalNumber operator-(const RationalNumber& other) const {
        return RationalNumber(
            numerator * other.denominator - other.numerator * denominator,
            denominator * other.denominator);
    }

    RationalNumber operator*(const RationalNumber& other) const {
        return RationalNumber(numerator * other.numerator,
                              denominator * other.denominator);
    }

    RationalNumber operator/(const RationalNumber& other) const {
        return RationalNumber(numerator * other.denominator,
                              denominator * other.numerator);
    }

    bool operator==(const RationalNumber& other) const {
        return numerator == other.numerator && denominator == other.denominator;
    }

    bool operator!=(const RationalNumber& other) const {
        return !(*this == other);
    }

    bool operator<(const RationalNumber& other) const {
        return numerator * other.denominator < other.numerator * denominator;
    }

    bool operator>(const RationalNumber& other) const {
        return other < *this;
    }

    bool operator<=(const RationalNumber& other) const {
        return !(*this > other);
    }

    bool operator>=(const RationalNumber& other) const {
        return !(*this < other);
    }

    void print() const {
        std::cout << numerator;
        if (denominator != 1)
            std::cout << "/" << denominator;
    }

    double toDouble() const {
        return static_cast<double>(numerator) / denominator;
    }

private:
    int numerator;
    int denominator;
};

int main() {
    RationalNumber a(1, 2);
    RationalNumber b(2, 4);  // should reduce to 1/2
    RationalNumber c(0, 1);

    std::cout << "a = "; a.print(); std::cout << std::endl;
    std::cout << "b = "; b.print(); std::cout << " (reduced from 2/4)" << std::endl;
    std::cout << "c = "; c.print(); std::cout << std::endl;

    RationalNumber sum = a + RationalNumber(1, 4);
    std::cout << "1/2 + 1/4 = "; sum.print(); std::cout << " = " << sum.toDouble() << std::endl;

    RationalNumber diff = a - RationalNumber(1, 4);
    std::cout << "1/2 - 1/4 = "; diff.print(); std::cout << " = " << diff.toDouble() << std::endl;

    RationalNumber prod = RationalNumber(2, 3) * RationalNumber(3, 4);
    std::cout << "2/3 * 3/4 = "; prod.print(); std::cout << " = " << prod.toDouble() << std::endl;

    RationalNumber quot = a / RationalNumber(1, 4);
    std::cout << "1/2 / 1/4 = "; quot.print(); std::cout << " = " << quot.toDouble() << std::endl;

    // Test comparisons
    std::cout << std::boolalpha;
    std::cout << "a == b: " << (a == b) << std::endl;
    std::cout << "a != c: " << (a != c) << std::endl;
    std::cout << "a > c: " << (a > c) << std::endl;
    std::cout << "c < a: " << (c < a) << std::endl;
    std::cout << "a <= b: " << (a <= b) << std::endl;
    std::cout << "a >= b: " << (a >= b) << std::endl;

    // Test negative denominator handling
    RationalNumber d(1, -3);
    std::cout << "1/-3 = "; d.print(); std::cout << std::endl;

    // Test zero denominator
    RationalNumber e(5, 0);
    std::cout << "5/0 → "; e.print(); std::cout << " (denominator set to 1)" << std::endl;

    return 0;
}
