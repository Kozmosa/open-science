# Test Cases for 9-20 SavingsAccount Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Initial balances | saver1($2000), saver2($3000) | $2000.00, $3000.00 |
| Month 1 at 3% | saver1 = 2000 * 0.03 / 12 | $2005.00 |
| Month 1 at 3% | saver2 = 3000 * 0.03 / 12 | $3007.50 |
| Month 2 at 4% | saver1 = 2005 * 0.04 / 12 | $2011.68 |
| Month 2 at 4% | saver2 = 3007.50 * 0.04 / 12 | $3017.53 |
| modifyInterestRate | Set to 0.05 | annualInterestRate = 0.05 |
| Default balance | `SavingsAccount s;` | $0.00 |
