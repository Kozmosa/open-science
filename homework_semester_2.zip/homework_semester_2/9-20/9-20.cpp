#include <iostream>
#include <iomanip>

class SavingsAccount {
public:
    SavingsAccount(double balance = 0.0) : savingsBalance(balance) {}

    void calculateMonthlyInterest() {
        savingsBalance += savingsBalance * annualInterestRate / 12.0;
    }

    static void modifyInterestRate(double newRate) {
        annualInterestRate = newRate;
    }

    double getBalance() const { return savingsBalance; }

private:
    double savingsBalance;
    static double annualInterestRate;
};

double SavingsAccount::annualInterestRate = 0.0;

int main() {
    SavingsAccount saver1(2000.00);
    SavingsAccount saver2(3000.00);

    std::cout << std::fixed << std::setprecision(2);

    std::cout << "Initial balances:" << std::endl;
    std::cout << "saver1: $" << saver1.getBalance() << std::endl;
    std::cout << "saver2: $" << saver2.getBalance() << std::endl;

    SavingsAccount::modifyInterestRate(0.03);
    std::cout << "\nSetting annual interest rate to 3%" << std::endl;

    saver1.calculateMonthlyInterest();
    saver2.calculateMonthlyInterest();
    std::cout << "After month 1:" << std::endl;
    std::cout << "saver1: $" << saver1.getBalance() << std::endl;
    std::cout << "saver2: $" << saver2.getBalance() << std::endl;

    SavingsAccount::modifyInterestRate(0.04);
    std::cout << "\nSetting annual interest rate to 4%" << std::endl;

    saver1.calculateMonthlyInterest();
    saver2.calculateMonthlyInterest();
    std::cout << "After month 2:" << std::endl;
    std::cout << "saver1: $" << saver1.getBalance() << std::endl;
    std::cout << "saver2: $" << saver2.getBalance() << std::endl;

    return 0;
}
