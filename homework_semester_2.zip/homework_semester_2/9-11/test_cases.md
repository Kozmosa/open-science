# Test Cases for 9-11 Rectangle Class

| Test | Input | Expected Output |
|------|-------|-----------------|
| Default constructor | `Rectangle r;` | length=1, width=1, perimeter=4, area=1 |
| Valid dimensions | `Rectangle(5, 3)` | length=5, width=3, perimeter=16, area=15 |
| Negative length | `setLength(-5)` | length resets to 1 |
| Length > 20 | `setLength(25)` | length resets to 1 |
| Edge lower bound | `setLength(0.01)` | length=0.01 |
| Edge upper bound | `setWidth(19.99)` | width=19.99 |
