#include <iostream>

class Rectangle {
public:
    Rectangle(double l = 1.0, double w = 1.0) {
        setLength(l);
        setWidth(w);
    }

    void setLength(double l) {
        if (l > 0.0 && l < 20.0)
            length = l;
        else
            length = 1.0;
    }

    void setWidth(double w) {
        if (w > 0.0 && w < 20.0)
            width = w;
        else
            width = 1.0;
    }

    double getLength() const { return length; }
    double getWidth() const { return width; }

    double perimeter() const {
        return 2.0 * (length + width);
    }

    double area() const {
        return length * width;
    }

private:
    double length;
    double width;
};

int main() {
    Rectangle r1;
    std::cout << "Default rectangle: length=" << r1.getLength()
              << " width=" << r1.getWidth()
              << " perimeter=" << r1.perimeter()
              << " area=" << r1.area() << std::endl;

    Rectangle r2(5.0, 3.0);
    std::cout << "5x3 rectangle: length=" << r2.getLength()
              << " width=" << r2.getWidth()
              << " perimeter=" << r2.perimeter()
              << " area=" << r2.area() << std::endl;

    // Test invalid values
    r2.setLength(-5.0);
    std::cout << "After setLength(-5): length=" << r2.getLength()
              << " (should be reset to 1)" << std::endl;

    r2.setLength(25.0);
    std::cout << "After setLength(25): length=" << r2.getLength()
              << " (should be reset to 1)" << std::endl;

    r2.setLength(10.0);
    r2.setWidth(5.0);
    std::cout << "10x5 rectangle: perimeter=" << r2.perimeter()
              << " area=" << r2.area() << std::endl;

    // Edge cases
    r2.setLength(0.01);
    r2.setWidth(19.99);
    std::cout << "0.01x19.99 rectangle: perimeter=" << r2.perimeter()
              << " area=" << r2.area() << std::endl;

    return 0;
}
